package com.driden.job_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
